"""Business logic and reusable helper functions for the enhanced dashboard."""
from __future__ import annotations

import heapq
import re
from typing import Any, Iterable

# The rescue profiles are dictionaries so the scoring rules are centralized,
# readable, and easy to change without rewriting the ranking algorithm.
RESCUE_PROFILES: dict[str, dict[str, Any]] = {
    "water": {
        "label": "Water Rescue",
        "breed_weights": {
            "labrador": 50,
            "retriever": 50,
            "newfoundland": 45,
            "chesapeake": 45,
        },
        "ideal_age_weeks": (52.0, 416.0),
        "acceptable_age_weeks": (26.0, 520.0),
    },
    "mountain": {
        "label": "Mountain/Wilderness Rescue",
        "breed_weights": {
            "german shepherd": 50,
            "malinois": 50,
            "husky": 45,
            "rottweiler": 45,
        },
        "ideal_age_weeks": (52.0, 416.0),
        "acceptable_age_weeks": (26.0, 520.0),
    },
    "disaster": {
        "label": "Disaster/Individual Tracking",
        "breed_weights": {
            "bloodhound": 50,
            "beagle": 45,
            "coonhound": 45,
        },
        "ideal_age_weeks": (52.0, 416.0),
        "acceptable_age_weeks": (26.0, 520.0),
    },
}

# Keep the original filtering vocabulary in one place so query construction and
# ranking profiles remain consistent.
RESCUE_BREEDS = {
    rescue_type: list(profile["breed_weights"].keys())
    for rescue_type, profile in RESCUE_PROFILES.items()
}

SEARCHABLE_FIELDS = ("name", "breed", "animal_id")
ANIMAL_ID_PATTERN = re.compile(r"^[Aa]\d{3,}$")
MAX_RANK_LIMIT = 100


def build_rescue_query(filter_type: str | None, search_term: str | None = None) -> dict[str, Any]:
    """Build a MongoDB query for a rescue filter plus optional user search.

    User search text is escaped before being used in a regular expression so it is
    treated as literal text instead of regex syntax.
    """
    clauses: list[dict[str, Any]] = []

    if filter_type in RESCUE_BREEDS:
        breed_pattern = "|".join(re.escape(breed) for breed in RESCUE_BREEDS[filter_type])
        clauses.append(
            {
                "animal_type": "Dog",
                "breed": {"$regex": breed_pattern, "$options": "i"},
            }
        )

    term = (search_term or "").strip()
    if term:
        # Austin Animal Center IDs normally look like A123456. Exact ID searches
        # use equality so MongoDB can use the animal_id index efficiently. Other
        # user searches remain escaped case-insensitive text searches.
        if ANIMAL_ID_PATTERN.fullmatch(term):
            clauses.append({"animal_id": term.upper()})
        else:
            escaped = re.escape(term)
            clauses.append(
                {
                    "$or": [
                        {field: {"$regex": escaped, "$options": "i"}}
                        for field in SEARCHABLE_FIELDS
                    ]
                }
            )

    if not clauses:
        return {}
    if len(clauses) == 1:
        return clauses[0]
    return {"$and": clauses}


def normalize_records(records: Iterable[dict[str, Any]] | None) -> list[dict[str, Any]]:
    """Prepare MongoDB documents for Dash without mutating original records.

    MongoDB's internal ``_id`` is converted to a string ``record_id`` so the UI
    can safely target one exact document for update/delete operations instead of
    using a broad filter that could modify multiple records.
    """
    normalized: list[dict[str, Any]] = []
    for record in records or []:
        clean = dict(record)
        mongo_id = clean.pop("_id", None)
        if mongo_id is not None:
            clean["record_id"] = str(mongo_id)
        normalized.append(clean)
    return normalized


def candidate_summary(record: dict[str, Any] | None) -> dict[str, str]:
    """Return readable candidate details for the selected dashboard row."""
    if not record:
        return {}

    age = record.get("age_upon_outcome") or record.get("age_upon_outcome_in_weeks") or "Unknown"
    return {
        "Animal ID": str(record.get("animal_id") or "Unknown"),
        "Name": str(record.get("name") or "Unnamed"),
        "Animal Type": str(record.get("animal_type") or "Unknown"),
        "Breed": str(record.get("breed") or "Unknown"),
        "Sex": str(record.get("sex_upon_outcome") or "Unknown"),
        "Age": str(age),
        "Outcome": str(record.get("outcome_type") or "Unknown"),
    }


def get_coordinates(record: dict[str, Any] | None) -> tuple[float, float] | None:
    """Return latitude/longitude using named fields instead of fragile column indexes."""
    if not record:
        return None

    latitude_keys = ("location_lat", "latitude", "lat")
    longitude_keys = ("location_long", "longitude", "lon", "lng")

    lat = next((record.get(key) for key in latitude_keys if record.get(key) is not None), None)
    lon = next((record.get(key) for key in longitude_keys if record.get(key) is not None), None)

    try:
        if lat is None or lon is None:
            return None
        return float(lat), float(lon)
    except (TypeError, ValueError):
        return None


def age_to_weeks(record: dict[str, Any] | None) -> float | None:
    """Convert an available age value to weeks for consistent scoring.

    The Austin data can expose age as a numeric week value or as text such as
    ``"3 years"``. Unknown or malformed ages return ``None`` instead of causing
    the ranking process to fail.
    """
    if not record:
        return None

    numeric_weeks = record.get("age_upon_outcome_in_weeks")
    if numeric_weeks not in (None, ""):
        try:
            value = float(numeric_weeks)
            return value if value >= 0 else None
        except (TypeError, ValueError):
            pass

    text_age = str(record.get("age_upon_outcome") or "").strip().lower()
    if not text_age:
        return None

    match = re.search(r"(-?\d+(?:\.\d+)?)\s*(year|month|week|day)", text_age)
    if not match:
        return None

    amount = float(match.group(1))
    if amount < 0:
        return None

    unit = match.group(2)
    conversion = {
        "year": 52.0,
        "month": 52.0 / 12.0,
        "week": 1.0,
        "day": 1.0 / 7.0,
    }
    return amount * conversion[unit]


def score_candidate(record: dict[str, Any], rescue_type: str) -> dict[str, Any]:
    """Calculate a transparent 0-100 rescue-candidate suitability score.

    The score intentionally uses only fields available in the artifact. It is a
    demonstration of algorithmic ranking for the capstone, not a real-world
    certification that an animal is suitable for rescue work.
    """
    if rescue_type not in RESCUE_PROFILES:
        raise ValueError(f"Unknown rescue type: {rescue_type}")

    profile = RESCUE_PROFILES[rescue_type]
    score = 0
    reasons: list[str] = []

    animal_type = str(record.get("animal_type") or "").strip().lower()
    if animal_type == "dog":
        score += 20
        reasons.append("dog candidate +20")

    breed_text = str(record.get("breed") or "").lower()
    breed_score = 0
    breed_match = ""
    for keyword, weight in profile["breed_weights"].items():
        if keyword in breed_text and weight > breed_score:
            breed_score = int(weight)
            breed_match = keyword.title()
    if breed_score:
        score += breed_score
        reasons.append(f"{breed_match} breed match +{breed_score}")

    weeks = age_to_weeks(record)
    if weeks is None:
        reasons.append("age unavailable +0")
    else:
        ideal_min, ideal_max = profile["ideal_age_weeks"]
        acceptable_min, acceptable_max = profile["acceptable_age_weeks"]
        if ideal_min <= weeks <= ideal_max:
            score += 30
            reasons.append("age in ideal range +30")
        elif acceptable_min <= weeks <= acceptable_max:
            score += 15
            reasons.append("age in acceptable range +15")
        else:
            score += 5
            reasons.append("age known but outside preferred range +5")

    return {
        "score": min(score, 100),
        "reasons": reasons,
        "age_weeks": weeks,
        "rescue_type": rescue_type,
    }


def rank_candidates(
    records: Iterable[dict[str, Any]] | None,
    rescue_type: str,
    k: int = 10,
) -> list[dict[str, Any]]:
    """Return the top ``k`` candidates using a bounded min-heap.

    Each candidate is scored once. The heap stores at most ``k`` entries, so
    ranking ``n`` records takes O(n log k) time and O(k) additional heap space.
    A unique input index prevents tied scores from forcing Python to compare
    dictionary objects.
    """
    if rescue_type not in RESCUE_PROFILES:
        raise ValueError(f"Unknown rescue type: {rescue_type}")
    if not isinstance(k, int) or isinstance(k, bool) or k <= 0:
        raise ValueError("k must be a positive integer.")
    if k > MAX_RANK_LIMIT:
        raise ValueError(f"k cannot exceed {MAX_RANK_LIMIT}.")

    heap: list[tuple[int, str, int, dict[str, Any]]] = []

    for index, record in enumerate(records or []):
        if not isinstance(record, dict):
            continue

        result = score_candidate(record, rescue_type)
        score = int(result["score"])
        animal_id = str(record.get("animal_id") or "")
        candidate = {
            "rank": 0,
            "score": score,
            "animal_id": animal_id or "Unknown",
            "name": str(record.get("name") or "Unnamed"),
            "breed": str(record.get("breed") or "Unknown"),
            "age": str(
                record.get("age_upon_outcome")
                or record.get("age_upon_outcome_in_weeks")
                or "Unknown"
            ),
            "why_ranked": "; ".join(result["reasons"]),
        }

        # animal_id and index create deterministic tie-breaking while keeping the
        # dictionary itself out of tuple comparisons.
        entry = (score, animal_id, index, candidate)
        if len(heap) < k:
            heapq.heappush(heap, entry)
        elif entry[:3] > heap[0][:3]:
            heapq.heapreplace(heap, entry)

    ordered = sorted(heap, key=lambda item: (item[0], item[1], item[2]), reverse=True)
    ranked: list[dict[str, Any]] = []
    for rank, (_, _, _, candidate) in enumerate(ordered, start=1):
        display_record = dict(candidate)
        display_record["rank"] = rank
        ranked.append(display_record)
    return ranked
