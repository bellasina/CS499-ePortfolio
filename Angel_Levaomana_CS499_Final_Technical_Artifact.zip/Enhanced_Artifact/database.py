"""MongoDB data-access layer for the CS 499 enhanced dashboard.

Milestone Four expands the repository from read-only access to controlled CRUD,
index management, validation, and aggregation while keeping database errors and
credentials out of the user interface.
"""
from __future__ import annotations

import logging
from typing import Any

from bson import ObjectId
from bson.errors import InvalidId
from pymongo import ASCENDING, DESCENDING, MongoClient
from pymongo.errors import PyMongoError

from config import Settings

logger = logging.getLogger(__name__)


class DatabaseConnectionError(RuntimeError):
    """Raised when the application cannot create a usable MongoDB connection."""


class DatabaseOperationError(RuntimeError):
    """Raised when a database operation fails after input has been validated."""


class DatabaseValidationError(ValueError):
    """Raised when a record or record identifier does not pass validation."""


# Keep the dashboard management form intentionally small and allow-listed. This
# prevents arbitrary database fields/operators from being submitted through the UI.
ALLOWED_RECORD_FIELDS = {
    "animal_id",
    "name",
    "animal_type",
    "breed",
    "age_upon_outcome",
    "sex_upon_outcome",
    "outcome_type",
    "location_lat",
    "location_long",
}
REQUIRED_CREATE_FIELDS = ("animal_id", "animal_type", "breed")
TEXT_FIELDS = {
    "animal_id",
    "name",
    "animal_type",
    "breed",
    "age_upon_outcome",
    "sex_upon_outcome",
    "outcome_type",
}
COORDINATE_FIELDS = {"location_lat", "location_long"}
MAX_TEXT_LENGTH = 200


def _clean_text(value: Any, field_name: str) -> str:
    if not isinstance(value, str):
        raise DatabaseValidationError(f"{field_name.replace('_', ' ').title()} must be text.")
    cleaned = value.strip()
    if len(cleaned) > MAX_TEXT_LENGTH:
        raise DatabaseValidationError(
            f"{field_name.replace('_', ' ').title()} cannot exceed {MAX_TEXT_LENGTH} characters."
        )
    return cleaned


def validate_animal_record(data: dict[str, Any] | None, *, partial: bool = False) -> dict[str, Any]:
    """Validate and normalize a dashboard create/update payload.

    Create operations require animal_id, animal_type, and breed. Update operations
    may be partial, but they still accept only the allow-listed fields and expected
    data types. Blank optional values are omitted so an accidental empty field does
    not overwrite existing database data.
    """
    if not isinstance(data, dict):
        raise DatabaseValidationError("Animal data must be provided as a record.")

    unknown = set(data) - ALLOWED_RECORD_FIELDS
    if unknown:
        raise DatabaseValidationError("The record contains unsupported fields.")

    cleaned: dict[str, Any] = {}
    for field, value in data.items():
        if value in (None, ""):
            continue
        if field in TEXT_FIELDS:
            text_value = _clean_text(value, field)
            if text_value:
                cleaned[field] = text_value
        elif field in COORDINATE_FIELDS:
            try:
                numeric = float(value)
            except (TypeError, ValueError) as exc:
                raise DatabaseValidationError(
                    f"{field.replace('_', ' ').title()} must be a number."
                ) from exc
            if field == "location_lat" and not -90 <= numeric <= 90:
                raise DatabaseValidationError("Location latitude must be between -90 and 90.")
            if field == "location_long" and not -180 <= numeric <= 180:
                raise DatabaseValidationError("Location longitude must be between -180 and 180.")
            cleaned[field] = numeric

    if partial:
        # animal_id remains editable only through the create path so updates cannot
        # silently change the identity shown in shelter records.
        cleaned.pop("animal_id", None)
        if not cleaned:
            raise DatabaseValidationError("Enter at least one field to update.")
    else:
        missing = [field for field in REQUIRED_CREATE_FIELDS if not cleaned.get(field)]
        if missing:
            readable = ", ".join(field.replace("_", " ") for field in missing)
            raise DatabaseValidationError(f"Missing required field(s): {readable}.")

    return cleaned


def validate_record_id(record_id: str | None) -> ObjectId:
    """Return a MongoDB ObjectId for a record selected from the dashboard."""
    value = (record_id or "").strip()
    if not value:
        raise DatabaseValidationError("Select a database record before updating or deleting it.")
    try:
        return ObjectId(value)
    except (InvalidId, TypeError) as exc:
        raise DatabaseValidationError("The selected database record ID is not valid.") from exc


class AnimalShelterRepository:
    """MongoDB repository for the Grazioso Salvare dashboard."""

    def __init__(self, settings: Settings):
        try:
            client_options = {
                "host": settings.mongo_host,
                "port": settings.mongo_port,
                "serverSelectionTimeoutMS": 5000,
            }

            # Use authentication when credentials are configured. This also supports
            # a local development MongoDB instance with authentication disabled.
            if settings.credentials_configured:
                client_options.update(
                    username=settings.mongo_username,
                    password=settings.mongo_password,
                    authSource="admin",
                )

            self.client = MongoClient(**client_options)
            self.database = self.client[settings.mongo_db]
            self.collection = self.database[settings.mongo_collection]
            self.client.admin.command("ping")
            self.ensure_indexes()
        except PyMongoError as exc:
            logger.error("MongoDB connection or startup index check failed (%s).", exc.__class__.__name__)
            raise DatabaseConnectionError(
                "The application could not connect to MongoDB. Check the database settings."
            ) from exc

    def ensure_indexes(self) -> list[str]:
        """Create or verify indexes used by common dashboard lookups and filters."""
        try:
            names = [
                self.collection.create_index(
                    [("animal_id", ASCENDING)], name="idx_animal_id"
                ),
                self.collection.create_index(
                    [("name", ASCENDING)], name="idx_name"
                ),
                self.collection.create_index(
                    [("animal_type", ASCENDING), ("breed", ASCENDING)],
                    name="idx_animal_type_breed",
                ),
                self.collection.create_index(
                    [("outcome_type", ASCENDING)], name="idx_outcome_type"
                ),
            ]
            return names
        except PyMongoError as exc:
            logger.error("MongoDB index creation/check failed (%s).", exc.__class__.__name__)
            raise DatabaseOperationError("Database indexes could not be prepared.") from exc

    def read(self, query: dict[str, Any] | None = None, limit: int = 0) -> list[dict[str, Any]]:
        """Return records matching a validated MongoDB query."""
        if query is None:
            query = {}
        if not isinstance(query, dict):
            raise ValueError("Query must be a dictionary.")
        if not isinstance(limit, int) or isinstance(limit, bool) or limit < 0:
            raise ValueError("Limit must be a non-negative integer.")

        try:
            cursor = self.collection.find(query)
            if limit:
                cursor = cursor.limit(limit)
            return list(cursor)
        except PyMongoError as exc:
            logger.error("MongoDB read failed (%s).", exc.__class__.__name__)
            raise DatabaseOperationError("Animal records could not be retrieved.") from exc

    def create(self, data: dict[str, Any]) -> str:
        """Validate and insert one animal record; return its database record ID."""
        clean = validate_animal_record(data, partial=False)
        try:
            result = self.collection.insert_one(clean)
            if not result.acknowledged:
                raise DatabaseOperationError("The new record was not acknowledged by the database.")
            return str(result.inserted_id)
        except PyMongoError as exc:
            logger.error("MongoDB create failed (%s).", exc.__class__.__name__)
            raise DatabaseOperationError("The animal record could not be created.") from exc

    def update_by_record_id(self, record_id: str, updates: dict[str, Any]) -> int:
        """Validate and update exactly one MongoDB document selected by ObjectId."""
        object_id = validate_record_id(record_id)
        clean = validate_animal_record(updates, partial=True)
        try:
            result = self.collection.update_one({"_id": object_id}, {"$set": clean})
            return int(result.modified_count)
        except PyMongoError as exc:
            logger.error("MongoDB update failed (%s).", exc.__class__.__name__)
            raise DatabaseOperationError("The selected animal record could not be updated.") from exc

    def delete_by_record_id(self, record_id: str) -> int:
        """Delete exactly one MongoDB document selected by ObjectId."""
        object_id = validate_record_id(record_id)
        try:
            result = self.collection.delete_one({"_id": object_id})
            return int(result.deleted_count)
        except PyMongoError as exc:
            logger.error("MongoDB delete failed (%s).", exc.__class__.__name__)
            raise DatabaseOperationError("The selected animal record could not be deleted.") from exc

    def aggregate_breed_summary(
        self,
        query: dict[str, Any] | None = None,
        *,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        """Summarize matching records by breed using MATCH/GROUP/SORT stages."""
        if query is None:
            query = {}
        if not isinstance(query, dict):
            raise ValueError("Query must be a dictionary.")
        if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 50:
            raise ValueError("Summary limit must be an integer from 1 to 50.")

        pipeline = [
            {"$match": query},
            {
                "$group": {
                    "_id": {
                        "animal_type": {"$ifNull": ["$animal_type", "Unknown"]},
                        "breed": {"$ifNull": ["$breed", "Unknown"]},
                    },
                    "count": {"$sum": 1},
                }
            },
            {"$sort": {"count": DESCENDING, "_id.breed": ASCENDING}},
            {"$limit": limit},
            {
                "$project": {
                    "_id": 0,
                    "animal_type": "$_id.animal_type",
                    "breed": "$_id.breed",
                    "count": 1,
                }
            },
        ]
        try:
            return list(self.collection.aggregate(pipeline))
        except PyMongoError as exc:
            logger.error("MongoDB aggregation failed (%s).", exc.__class__.__name__)
            raise DatabaseOperationError("The database summary could not be generated.") from exc

    def close(self) -> None:
        """Close the MongoDB client cleanly."""
        self.client.close()
