# Grazioso Salvare Dashboard - CS 499 Database Enhancement

This folder contains the enhanced version of the CS 340 Grazioso Salvare dashboard for CS 499 Milestone Four. It preserves the modular software-engineering improvements from Milestone Two and the rescue-candidate ranking algorithm from Milestone Three, then expands the artifact with database-focused improvements.

## Milestone Four enhancement

The original project included a Python `AnimalShelter` CRUD class, but the dashboard itself mainly read records from MongoDB. Update and delete operations could also affect multiple matching records because the original class used `update_many()` and `delete_many()` with general query filters. The Milestone Four enhancement makes database use more controlled, visible, and secure.

### Database improvements

- **Validated create/update data:** `validate_animal_record()` checks an allow-list of supported fields, required create fields, text length, and latitude/longitude ranges before a write is sent to MongoDB.
- **Exact record targeting:** MongoDB `_id` values are converted to a dashboard-safe string named `record_id`. Update and delete operations use that exact ObjectId with `update_one()` and `delete_one()` instead of broad multi-record operations.
- **Controlled CRUD interface:** The dashboard includes a data-management form for create and update actions. Selecting a row loads the exact record into the form. Delete actions require a confirmation dialog.
- **Automatic refresh after writes:** A Dash `dcc.Store` revision value triggers a fresh database read after a successful create, update, or delete, so the table, ranking results, and summary stay current. The table selection is cleared after a successful write so a stale row selection cannot accidentally target a different refreshed record.
- **Index management and query optimization:** The repository creates or verifies indexes for `animal_id`, `name`, `outcome_type`, and the compound pair `animal_type + breed` at startup. Exact animal-ID searches use equality so the `animal_id` index can directly support that lookup.
- **MongoDB aggregation:** `aggregate_breed_summary()` uses `$match`, `$group`, `$sort`, `$limit`, and `$project` to summarize the top breeds in the current filtered result. The dashboard displays the summary in both a table and a chart.
- **Safer error handling:** Database exceptions are logged by operation and exception type while the user sees a short, non-sensitive message. Credentials and raw database errors are not shown in the interface.
- **Secure configuration retained:** MongoDB settings continue to come from environment variables through `.env`; authenticated MongoDB credentials are supported when configured, while a local development instance can also run with the username/password fields left blank. The real `.env` is excluded from the submission.

## Previous enhancements retained

### Software Engineering and Design

- Refactored the original notebook into application, configuration, database, service, layout, and callback modules.
- Added search and a Candidate Details panel.
- Added reusable query and record-normalization functions.
- Added safer user-facing fallback messages and automated tests.

### Algorithms and Data Structures

- `RESCUE_PROFILES` dictionaries centralize ranking rules.
- `score_candidate()` produces transparent suitability scores.
- `rank_candidates()` uses a bounded min-heap / priority queue to keep the top `k` candidates in O(n log k) time with O(k) extra heap space.
- The dashboard displays a Top Rescue Candidates table with score explanations.

## Files

- `app.py` - application entry point and startup database handling
- `config.py` - environment-based configuration
- `database.py` - MongoDB connection, validation, indexes, CRUD, aggregation, and safe database errors
- `services.py` - filtering, normalization, candidate details, scoring, and heap-based ranking
- `layout.py` - dashboard layout, database summary, CRUD form, tables, and confirmation dialog
- `callbacks.py` - interactive filtering, ranking, aggregation, CRUD, refresh, chart, details, and map callbacks
- `tests/test_services.py` - service/ranking tests
- `tests/test_database.py` - database validation, index, CRUD-targeting, and aggregation tests
- `tests/conftest.py` - test-only fallback dependency stubs for isolated environments without PyMongo; the production app still requires PyMongo
- `.env.example` - safe configuration template
- `requirements.txt` - Python dependencies
- `TEST_RESULTS.txt` - verification record for Milestone Four

## Setup

1. Install the dependencies in `requirements.txt`.
2. Copy `.env.example` to `.env`.
3. Configure `.env` for the local MongoDB instance. If authentication is enabled, enter the username and password; if the local development instance has authentication disabled, leave those two values blank.
4. Use a local MongoDB database named `aac` with a collection named `animals`.
5. Run `py app.py` on Windows (or `python app.py` on other systems).
6. Open the local Dash address shown in the terminal.
7. Use Search and Filter to view records, rescue rankings, and the MongoDB summary.
8. Select an existing table row to update or delete one exact record, or enter required fields to create a new record.

The real `.env` file is intentionally excluded because it contains private credentials.

## Automated verification

Run:

```text
py -m pytest -q
```

Milestone Four contains 30 automated tests covering the previous service/ranking behavior plus record validation, ObjectId validation, index creation, exact-record update/delete targeting, MongoDB aggregation pipeline construction, and safe error translation.

Also run:

```text
py -m py_compile app.py callbacks.py config.py database.py layout.py services.py
```

A live MongoDB UI test requires the student's local database and local `.env` configuration, which is intentionally not included in the submission package. The tested local environment used MongoDB on `localhost:27017` with authentication disabled.


## Live verification completed

The enhanced dashboard was also run against the student's local MongoDB environment after automated verification. The application successfully connected, loaded 173,775 records, checked indexes at startup, populated the Water Rescue filter and MongoDB aggregation summary, displayed ranked rescue candidates, loaded exact selected records into the management form, and completed a temporary create-update-delete cycle with confirmation before deletion. The temporary test record was removed after verification.
