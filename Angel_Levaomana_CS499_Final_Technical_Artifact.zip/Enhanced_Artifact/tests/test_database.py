from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
from bson import ObjectId
from pymongo import ASCENDING

from database import (
    AnimalShelterRepository,
    DatabaseOperationError,
    DatabaseValidationError,
    validate_animal_record,
    validate_record_id,
)


def repository_with_mock_collection():
    repository = AnimalShelterRepository.__new__(AnimalShelterRepository)
    repository.collection = MagicMock()
    repository.client = MagicMock()
    return repository


def test_validate_create_requires_expected_fields():
    with pytest.raises(DatabaseValidationError):
        validate_animal_record({"name": "Bella"})


def test_validate_create_cleans_text_and_coordinates():
    clean = validate_animal_record(
        {
            "animal_id": " A123 ",
            "animal_type": " Dog ",
            "breed": " Labrador Mix ",
            "location_lat": "30.25",
            "location_long": -97.75,
        }
    )
    assert clean["animal_id"] == "A123"
    assert clean["animal_type"] == "Dog"
    assert clean["breed"] == "Labrador Mix"
    assert clean["location_lat"] == 30.25
    assert clean["location_long"] == -97.75


def test_validate_rejects_unknown_fields_and_bad_coordinates():
    with pytest.raises(DatabaseValidationError):
        validate_animal_record(
            {"animal_id": "A1", "animal_type": "Dog", "breed": "Lab", "$where": "bad"}
        )
    with pytest.raises(DatabaseValidationError):
        validate_animal_record(
            {"animal_id": "A1", "animal_type": "Dog", "breed": "Lab", "location_lat": 100}
        )


def test_partial_update_does_not_change_animal_id():
    clean = validate_animal_record({"animal_id": "NEW", "name": "Updated"}, partial=True)
    assert clean == {"name": "Updated"}


def test_partial_update_requires_at_least_one_change():
    with pytest.raises(DatabaseValidationError):
        validate_animal_record({"animal_id": "A1"}, partial=True)


def test_validate_record_id_accepts_object_id_string():
    raw = "64f000000000000000000001"
    assert validate_record_id(raw) == ObjectId(raw)


def test_validate_record_id_rejects_invalid_value():
    with pytest.raises(DatabaseValidationError):
        validate_record_id("not-an-object-id")


def test_ensure_indexes_creates_expected_indexes():
    repository = repository_with_mock_collection()
    repository.collection.create_index.side_effect = [
        "idx_animal_id",
        "idx_name",
        "idx_animal_type_breed",
        "idx_outcome_type",
    ]
    names = repository.ensure_indexes()
    assert names == ["idx_animal_id", "idx_name", "idx_animal_type_breed", "idx_outcome_type"]
    assert repository.collection.create_index.call_count == 4
    repository.collection.create_index.assert_any_call(
        [("animal_type", ASCENDING), ("breed", ASCENDING)], name="idx_animal_type_breed"
    )


def test_create_validates_and_inserts_one_record():
    repository = repository_with_mock_collection()
    inserted_id = ObjectId("64f000000000000000000002")
    repository.collection.insert_one.return_value = SimpleNamespace(
        acknowledged=True, inserted_id=inserted_id
    )
    result = repository.create(
        {"animal_id": "A2", "animal_type": "Dog", "breed": "Labrador", "name": "Bella"}
    )
    assert result == str(inserted_id)
    repository.collection.insert_one.assert_called_once_with(
        {"animal_id": "A2", "animal_type": "Dog", "breed": "Labrador", "name": "Bella"}
    )


def test_update_targets_one_exact_record():
    repository = repository_with_mock_collection()
    repository.collection.update_one.return_value = SimpleNamespace(modified_count=1)
    record_id = "64f000000000000000000003"
    modified = repository.update_by_record_id(record_id, {"name": "Updated Name"})
    assert modified == 1
    repository.collection.update_one.assert_called_once_with(
        {"_id": ObjectId(record_id)}, {"$set": {"name": "Updated Name"}}
    )


def test_delete_targets_one_exact_record():
    repository = repository_with_mock_collection()
    repository.collection.delete_one.return_value = SimpleNamespace(deleted_count=1)
    record_id = "64f000000000000000000004"
    deleted = repository.delete_by_record_id(record_id)
    assert deleted == 1
    repository.collection.delete_one.assert_called_once_with({"_id": ObjectId(record_id)})


def test_aggregation_uses_match_group_sort_limit_project():
    repository = repository_with_mock_collection()
    repository.collection.aggregate.return_value = [
        {"animal_type": "Dog", "breed": "Labrador", "count": 12}
    ]
    result = repository.aggregate_breed_summary({"animal_type": "Dog"}, limit=5)
    assert result[0]["count"] == 12
    pipeline = repository.collection.aggregate.call_args.args[0]
    assert pipeline[0] == {"$match": {"animal_type": "Dog"}}
    assert "$group" in pipeline[1]
    assert "$sort" in pipeline[2]
    assert pipeline[3] == {"$limit": 5}
    assert "$project" in pipeline[4]


def test_database_errors_become_safe_application_error(monkeypatch):
    repository = repository_with_mock_collection()
    from pymongo.errors import PyMongoError

    repository.collection.find.side_effect = PyMongoError("server details")
    with pytest.raises(DatabaseOperationError, match="could not be retrieved"):
        repository.read({})
