import re

import pytest
from bson import ObjectId

from services import (
    age_to_weeks,
    build_rescue_query,
    candidate_summary,
    get_coordinates,
    normalize_records,
    rank_candidates,
    score_candidate,
)


def test_reset_returns_empty_query():
    assert build_rescue_query("reset", "") == {}


def test_water_filter_builds_dog_breed_query():
    query = build_rescue_query("water")
    assert query["animal_type"] == "Dog"
    assert "labrador" in query["breed"]["$regex"]
    assert query["breed"]["$options"] == "i"


def test_search_term_is_escaped():
    query = build_rescue_query("reset", "A.*B")
    pattern = query["$or"][0]["name"]["$regex"]
    assert pattern == re.escape("A.*B")



def test_exact_animal_id_search_uses_equality_query():
    query = build_rescue_query("reset", "a123456")
    assert query == {"animal_id": "A123456"}

def test_filter_and_search_are_combined():
    query = build_rescue_query("mountain", "Bella")
    assert "$and" in query
    assert len(query["$and"]) == 2


def test_normalize_records_converts_mongo_id_without_mutating_input():
    mongo_id = ObjectId("64f000000000000000000001")
    source = [{"_id": mongo_id, "name": "Ponyo"}]
    cleaned = normalize_records(source)
    assert "_id" not in cleaned[0]
    assert cleaned[0]["record_id"] == str(mongo_id)
    assert source[0]["_id"] == mongo_id


def test_candidate_summary_handles_missing_values():
    summary = candidate_summary({"name": "Bella", "breed": "Labrador"})
    assert summary["Name"] == "Bella"
    assert summary["Breed"] == "Labrador"
    assert summary["Animal ID"] == "Unknown"


def test_get_coordinates_uses_named_fields():
    assert get_coordinates({"location_lat": 30.75, "location_long": -97.48}) == (30.75, -97.48)


def test_get_coordinates_returns_none_for_invalid_data():
    assert get_coordinates({"location_lat": "not-a-number", "location_long": -97.48}) is None


def test_age_to_weeks_parses_text_age():
    assert age_to_weeks({"age_upon_outcome": "3 years"}) == pytest.approx(156.0)
    assert age_to_weeks({"age_upon_outcome": "6 months"}) == pytest.approx(26.0)


def test_age_to_weeks_prefers_numeric_week_field():
    assert age_to_weeks({"age_upon_outcome_in_weeks": 104, "age_upon_outcome": "9 years"}) == 104.0


def test_score_candidate_uses_profile_dictionary():
    record = {
        "animal_type": "Dog",
        "breed": "Labrador Retriever Mix",
        "age_upon_outcome": "3 years",
    }
    result = score_candidate(record, "water")
    assert result["score"] == 100
    assert any("breed match" in reason for reason in result["reasons"])
    assert any("ideal range" in reason for reason in result["reasons"])


def test_score_candidate_handles_missing_age_without_failure():
    result = score_candidate(
        {"animal_type": "Dog", "breed": "Newfoundland Mix"},
        "water",
    )
    assert result["score"] == 65
    assert "age unavailable +0" in result["reasons"]


def test_rank_candidates_returns_highest_scores_first_and_limits_k():
    records = [
        {
            "animal_id": "A1",
            "name": "Older",
            "animal_type": "Dog",
            "breed": "Newfoundland Mix",
            "age_upon_outcome": "12 years",
        },
        {
            "animal_id": "A2",
            "name": "Best",
            "animal_type": "Dog",
            "breed": "Labrador Retriever Mix",
            "age_upon_outcome": "3 years",
        },
        {
            "animal_id": "A3",
            "name": "Good",
            "animal_type": "Dog",
            "breed": "Chesapeake Mix",
            "age_upon_outcome": "4 years",
        },
    ]
    ranked = rank_candidates(records, "water", k=2)
    assert len(ranked) == 2
    assert ranked[0]["animal_id"] == "A2"
    assert ranked[0]["score"] >= ranked[1]["score"]
    assert [candidate["rank"] for candidate in ranked] == [1, 2]


def test_rank_candidates_ties_are_deterministic():
    records = [
        {"animal_id": "A1", "animal_type": "Dog", "breed": "Beagle", "age_upon_outcome": "3 years"},
        {"animal_id": "A2", "animal_type": "Dog", "breed": "Beagle", "age_upon_outcome": "3 years"},
    ]
    first = rank_candidates(records, "disaster", k=2)
    second = rank_candidates(records, "disaster", k=2)
    assert first == second


def test_rank_candidates_skips_non_dictionary_items():
    records = [
        None,
        "bad-record",
        {"animal_id": "A1", "animal_type": "Dog", "breed": "Bloodhound", "age_upon_outcome": "2 years"},
    ]
    ranked = rank_candidates(records, "disaster", k=10)
    assert len(ranked) == 1
    assert ranked[0]["animal_id"] == "A1"


def test_rank_candidates_validates_rescue_type_and_k():
    with pytest.raises(ValueError):
        rank_candidates([], "unknown", k=10)
    with pytest.raises(ValueError):
        rank_candidates([], "water", k=0)
    with pytest.raises(ValueError):
        rank_candidates([], "water", k=101)
