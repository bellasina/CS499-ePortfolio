"""Application configuration for the enhanced Grazioso Salvare dashboard."""
from dataclasses import dataclass
import os

try:
    from dotenv import load_dotenv
except ImportError:  # App can still use environment variables without python-dotenv.
    load_dotenv = None

if load_dotenv:
    load_dotenv()


@dataclass(frozen=True)
class Settings:
    mongo_username: str
    mongo_password: str
    mongo_host: str = "localhost"
    mongo_port: int = 27017
    mongo_db: str = "aac"
    mongo_collection: str = "animals"

    @property
    def credentials_configured(self) -> bool:
        return bool(self.mongo_username and self.mongo_password)


def get_settings() -> Settings:
    """Load database settings from environment variables only."""
    return Settings(
        mongo_username=os.getenv("MONGO_USERNAME", "").strip(),
        mongo_password=os.getenv("MONGO_PASSWORD", "").strip(),
        mongo_host=os.getenv("MONGO_HOST", "localhost").strip() or "localhost",
        mongo_port=int(os.getenv("MONGO_PORT", "27017")),
        mongo_db=os.getenv("MONGO_DB", "aac").strip() or "aac",
        mongo_collection=os.getenv("MONGO_COLLECTION", "animals").strip() or "animals",
    )
