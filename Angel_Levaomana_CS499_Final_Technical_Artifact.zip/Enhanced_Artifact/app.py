"""Entry point for the CS 499 enhanced Grazioso Salvare dashboard."""
from dash import Dash

from callbacks import register_callbacks
from config import get_settings
from database import AnimalShelterRepository, DatabaseConnectionError, DatabaseOperationError
from layout import build_layout
from services import normalize_records


def create_app() -> Dash:
    app = Dash(__name__)
    settings = get_settings()

    repository = None
    initial_records = []
    startup_message = ""

    try:
        repository = AnimalShelterRepository(settings)
        initial_records = normalize_records(repository.read({}))
        startup_message = (
            f"Connected to MongoDB. {len(initial_records)} record(s) loaded. "
            "Database indexes were checked at startup."
        )
    except (DatabaseConnectionError, DatabaseOperationError) as exc:
        startup_message = str(exc)

    app.layout = build_layout(initial_records, startup_message)

    if repository is not None:
        register_callbacks(app, repository)

    return app


app = create_app()
server = app.server

if __name__ == "__main__":
    app.run(debug=True)
