"""Callback registration for the enhanced dashboard."""
from __future__ import annotations

from dash import Input, Output, State, ctx, dcc, html, no_update
import dash_leaflet as dl
import pandas as pd
import plotly.express as px

from database import DatabaseOperationError, DatabaseValidationError
from services import (
    RESCUE_PROFILES,
    build_rescue_query,
    candidate_summary,
    get_coordinates,
    normalize_records,
    rank_candidates,
)


def _management_payload(
    animal_id,
    name,
    animal_type,
    breed,
    age,
    sex,
    outcome,
    latitude,
    longitude,
):
    return {
        "animal_id": animal_id,
        "name": name,
        "animal_type": animal_type,
        "breed": breed,
        "age_upon_outcome": age,
        "sex_upon_outcome": sex,
        "outcome_type": outcome,
        "location_lat": latitude,
        "location_long": longitude,
    }


def register_callbacks(app, repository):
    @app.callback(
        Output("datatable-id", "data"),
        Output("datatable-id", "columns"),
        Output("status-message", "children"),
        Output("ranking-table", "data"),
        Output("ranking-status", "children"),
        Output("summary-table", "data"),
        Output("summary-status", "children"),
        Output("summary-chart", "children"),
        Input("filter-type", "value"),
        Input("search-term", "value"),
        Input("data-revision", "data"),
    )
    def update_dashboard(filter_type, search_term, _revision):
        try:
            query = build_rescue_query(filter_type, search_term)
            records = normalize_records(repository.read(query))
            columns = [{"name": name, "id": name} for name in (records[0].keys() if records else [])]
            message = f"{len(records)} record(s) found."

            if filter_type in RESCUE_PROFILES:
                ranked = rank_candidates(records, filter_type, k=10)
                profile_label = RESCUE_PROFILES[filter_type]["label"]
                ranking_message = (
                    f"Top {len(ranked)} {profile_label} candidate(s), ranked with a bounded min-heap."
                    if ranked
                    else f"No {profile_label} candidates are available for the current search."
                )
            else:
                ranked = []
                ranking_message = "Choose a rescue category to calculate and rank candidate suitability scores."

            summary = repository.aggregate_breed_summary(query, limit=10)
            summary_message = (
                f"MongoDB grouped the current results into {len(summary)} top breed entr{'y' if len(summary) == 1 else 'ies'}."
                if summary
                else "No database summary is available for the current filters."
            )
            if summary:
                frame = pd.DataFrame.from_records(summary)
                summary_chart = dcc.Graph(
                    figure=px.bar(
                        frame,
                        x="breed",
                        y="count",
                        color="animal_type" if "animal_type" in frame.columns else None,
                        title="Top Breeds in Current MongoDB Results",
                    )
                )
            else:
                summary_chart = html.P("No data available for the database summary chart.")

            return (
                records,
                columns,
                message,
                ranked,
                ranking_message,
                summary,
                summary_message,
                summary_chart,
            )
        except (ValueError, DatabaseOperationError, RuntimeError):
            return (
                [],
                [],
                "Records could not be loaded. Check the search or database connection.",
                [],
                "Candidate ranking is unavailable until records can be loaded.",
                [],
                "Database summary is unavailable until records can be loaded.",
                html.P("Summary chart unavailable."),
            )

    @app.callback(
        Output("graph-id", "children"),
        Input("datatable-id", "derived_virtual_data"),
    )
    def update_graph(view_data):
        records = view_data or []
        if not records:
            return html.P("No data available for the breed chart.")
        frame = pd.DataFrame.from_records(records)
        if "breed" not in frame.columns or frame.empty:
            return html.P("Breed information is not available.")
        return dcc.Graph(figure=px.pie(frame, names="breed", title="Breed Distribution"))

    @app.callback(
        Output("candidate-details", "children"),
        Output("map-id", "children"),
        Input("datatable-id", "derived_virtual_data"),
        Input("datatable-id", "derived_virtual_selected_rows"),
    )
    def update_candidate(view_data, selected_rows):
        records = view_data or []
        if not records or not selected_rows:
            return html.P("Select an animal to view candidate details."), html.P(
                "Select an animal with location data to display the map."
            )

        row_index = selected_rows[0]
        if row_index < 0 or row_index >= len(records):
            return html.P("The selected row is no longer available."), html.P("Map unavailable.")

        record = records[row_index]
        details = candidate_summary(record)
        detail_view = html.Ul([html.Li([html.Strong(f"{key}: "), value]) for key, value in details.items()])

        coordinates = get_coordinates(record)
        if coordinates is None:
            return detail_view, html.P("Location information is not available for this animal.")

        lat, lon = coordinates
        breed = str(record.get("breed") or "Unknown breed")
        name = str(record.get("name") or "Unnamed")
        map_view = dl.Map(
            center=[lat, lon],
            zoom=10,
            style={"width": "100%", "height": "500px"},
            children=[
                dl.TileLayer(),
                dl.Marker(
                    position=[lat, lon],
                    children=[dl.Tooltip(breed), dl.Popup([html.H4("Animal Name"), html.P(name)])],
                ),
            ],
        )
        return detail_view, map_view

    @app.callback(
        Output("manage-record-id", "value"),
        Output("manage-animal-id", "value"),
        Output("manage-name", "value"),
        Output("manage-animal-type", "value"),
        Output("manage-breed", "value"),
        Output("manage-age", "value"),
        Output("manage-sex", "value"),
        Output("manage-outcome", "value"),
        Output("manage-lat", "value"),
        Output("manage-long", "value"),
        Input("datatable-id", "derived_virtual_data"),
        Input("datatable-id", "derived_virtual_selected_rows"),
    )
    def populate_management_form(view_data, selected_rows):
        records = view_data or []
        if not records or not selected_rows:
            return ("", "", "", "", "", "", "", "", "", "")
        row_index = selected_rows[0]
        if row_index < 0 or row_index >= len(records):
            return ("", "", "", "", "", "", "", "", "", "")
        record = records[row_index]
        return (
            record.get("record_id", ""),
            record.get("animal_id", ""),
            record.get("name", ""),
            record.get("animal_type", ""),
            record.get("breed", ""),
            record.get("age_upon_outcome", ""),
            record.get("sex_upon_outcome", ""),
            record.get("outcome_type", ""),
            record.get("location_lat", ""),
            record.get("location_long", ""),
        )

    @app.callback(
        Output("crud-status", "children"),
        Output("data-revision", "data"),
        Output("datatable-id", "selected_rows"),
        Input("create-record", "n_clicks"),
        Input("update-record", "n_clicks"),
        Input("delete-confirm", "submit_n_clicks"),
        State("data-revision", "data"),
        State("manage-record-id", "value"),
        State("manage-animal-id", "value"),
        State("manage-name", "value"),
        State("manage-animal-type", "value"),
        State("manage-breed", "value"),
        State("manage-age", "value"),
        State("manage-sex", "value"),
        State("manage-outcome", "value"),
        State("manage-lat", "value"),
        State("manage-long", "value"),
        prevent_initial_call=True,
    )
    def manage_record(
        _create_clicks,
        _update_clicks,
        _delete_clicks,
        revision,
        record_id,
        animal_id,
        name,
        animal_type,
        breed,
        age,
        sex,
        outcome,
        latitude,
        longitude,
    ):
        action = ctx.triggered_id
        payload = _management_payload(
            animal_id,
            name,
            animal_type,
            breed,
            age,
            sex,
            outcome,
            latitude,
            longitude,
        )
        current_revision = int(revision or 0)

        try:
            if action == "create-record":
                inserted_id = repository.create(payload)
                return (
                    f"Record created successfully. Database record ID: {inserted_id}",
                    current_revision + 1,
                    [],
                )

            if action == "update-record":
                modified = repository.update_by_record_id(record_id, payload)
                if modified:
                    return "Selected record updated successfully.", current_revision + 1, []
                return "No database values changed for the selected record.", no_update, no_update

            if action == "delete-confirm":
                deleted = repository.delete_by_record_id(record_id)
                if deleted:
                    return "Selected record deleted successfully.", current_revision + 1, []
                return "The selected record was not found, so nothing was deleted.", no_update, no_update

            return no_update, no_update, no_update
        except DatabaseValidationError as exc:
            return str(exc), no_update, no_update
        except DatabaseOperationError:
            return (
                "The database operation could not be completed. Check the connection and try again.",
                no_update,
                no_update,
            )
