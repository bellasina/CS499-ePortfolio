"""Dash layout for the enhanced Grazioso Salvare dashboard."""
from __future__ import annotations

import base64
from pathlib import Path
from typing import Any

from dash import dash_table, dcc, html


RANKING_COLUMNS = [
    {"name": "Rank", "id": "rank"},
    {"name": "Suitability Score", "id": "score"},
    {"name": "Animal ID", "id": "animal_id"},
    {"name": "Name", "id": "name"},
    {"name": "Breed", "id": "breed"},
    {"name": "Age", "id": "age"},
    {"name": "Why Ranked", "id": "why_ranked"},
]

SUMMARY_COLUMNS = [
    {"name": "Animal Type", "id": "animal_type"},
    {"name": "Breed", "id": "breed"},
    {"name": "Record Count", "id": "count"},
]


def _logo_component(logo_path: str | Path = "Grazioso Salvare Logo.png"):
    """Return the logo when available, or a safe text fallback when it is missing."""
    path = Path(logo_path)
    if path.exists() and path.is_file():
        encoded = base64.b64encode(path.read_bytes()).decode("utf-8")
        return html.Img(
            src=f"data:image/png;base64,{encoded}",
            style={"height": "120px", "maxWidth": "100%"},
            alt="Grazioso Salvare logo",
        )
    return html.H3("Grazioso Salvare", title="Logo file not found; text fallback displayed.")


def _management_input(label: str, input_id: str, *, placeholder: str = "", read_only: bool = False):
    return html.Div(
        [
            html.Label(label, htmlFor=input_id, style={"fontWeight": "bold"}),
            dcc.Input(
                id=input_id,
                type="text",
                placeholder=placeholder,
                readOnly=read_only,
                style={"width": "100%"},
            ),
        ],
        style={"minWidth": "220px", "flex": "1"},
    )


def build_layout(initial_records: list[dict[str, Any]] | None = None, startup_message: str = ""):
    records = initial_records or []
    columns = [{"name": name, "id": name} for name in (records[0].keys() if records else [])]

    return html.Div(
        [
            dcc.Store(id="data-revision", data=0),
            html.Center(html.H1("Grazioso Salvare Rescue Candidate Dashboard")),
            html.Center(
                [
                    html.A(_logo_component(), href="https://www.snhu.edu", target="_blank"),
                    html.H4("Angel Levaomana - CS 499 Database Enhancement"),
                ]
            ),
            html.Hr(),
            html.Div(
                [
                    html.H3("Search and Filter"),
                    dcc.Input(
                        id="search-term",
                        type="text",
                        placeholder="Search by animal name, breed, or animal ID",
                        debounce=True,
                        style={"width": "100%", "maxWidth": "520px", "marginBottom": "12px"},
                    ),
                    dcc.RadioItems(
                        id="filter-type",
                        options=[
                            {"label": "Reset (All)", "value": "reset"},
                            {"label": "Water Rescue", "value": "water"},
                            {"label": "Mountain/Wilderness Rescue", "value": "mountain"},
                            {"label": "Disaster/Individual Tracking", "value": "disaster"},
                        ],
                        value="reset",
                        inline=True,
                    ),
                    html.Div(
                        startup_message,
                        id="status-message",
                        role="status",
                        style={"marginTop": "10px", "fontWeight": "bold"},
                    ),
                ]
            ),
            html.Hr(),
            html.H3("Database Summary"),
            html.P(
                "This summary is produced by a MongoDB aggregation pipeline using the current search and rescue filters."
            ),
            html.Div(id="summary-status", role="status", style={"marginBottom": "10px", "fontWeight": "bold"}),
            html.Div(
                [
                    html.Div(
                        dash_table.DataTable(
                            id="summary-table",
                            columns=SUMMARY_COLUMNS,
                            data=[],
                            page_action="native",
                            page_size=10,
                            sort_action="native",
                            style_table={"overflowX": "auto"},
                            style_cell={"textAlign": "left", "padding": "6px"},
                            style_header={"fontWeight": "bold"},
                        ),
                        style={"flex": "1", "minWidth": "360px", "paddingRight": "20px"},
                    ),
                    html.Div(id="summary-chart", style={"flex": "1", "minWidth": "360px"}),
                ],
                style={"display": "flex", "flexWrap": "wrap"},
            ),
            html.Hr(),
            html.H3("Top Rescue Candidates"),
            html.P(
                "Select a rescue category to score matching animals and keep the strongest candidates "
                "in a priority queue. Higher scores appear first."
            ),
            html.Div(
                "Choose a rescue category to calculate and rank candidate suitability scores.",
                id="ranking-status",
                role="status",
                style={"marginBottom": "10px", "fontWeight": "bold"},
            ),
            dash_table.DataTable(
                id="ranking-table",
                columns=RANKING_COLUMNS,
                data=[],
                page_action="native",
                page_size=10,
                sort_action="native",
                style_table={"overflowX": "auto"},
                style_cell={
                    "textAlign": "left",
                    "padding": "6px",
                    "minWidth": "90px",
                    "maxWidth": "360px",
                    "whiteSpace": "normal",
                },
                style_header={"fontWeight": "bold"},
            ),
            html.Hr(),
            html.H3("All Matching Records"),
            html.P("Select a row to load that exact database record into the management form below."),
            dash_table.DataTable(
                id="datatable-id",
                columns=columns,
                data=records,
                row_selectable="single",
                selected_rows=[],
                sort_action="native",
                filter_action="native",
                page_action="native",
                page_size=10,
                style_table={"overflowX": "auto"},
                style_cell={"textAlign": "left", "padding": "6px", "minWidth": "100px"},
                style_header={"fontWeight": "bold"},
            ),
            html.Br(),
            html.Div(
                [
                    html.Div(
                        [html.H3("Candidate Details"), html.Div(id="candidate-details")],
                        style={"flex": "1", "minWidth": "300px", "paddingRight": "20px"},
                    ),
                    html.Div(id="graph-id", style={"flex": "1", "minWidth": "300px"}),
                ],
                style={"display": "flex", "flexWrap": "wrap"},
            ),
            html.Hr(),
            html.H3("Controlled Data Management"),
            html.P(
                "Create validates required fields before saving. Update and delete act on the exact MongoDB record selected in the table. Deletion requires confirmation."
            ),
            html.Div(
                [
                    _management_input("Database Record ID", "manage-record-id", read_only=True),
                    _management_input("Animal ID*", "manage-animal-id", placeholder="Required for new records"),
                    _management_input("Name", "manage-name"),
                    _management_input("Animal Type*", "manage-animal-type", placeholder="Example: Dog"),
                    _management_input("Breed*", "manage-breed", placeholder="Required for new records"),
                    _management_input("Age", "manage-age", placeholder="Example: 3 years"),
                    _management_input("Sex", "manage-sex"),
                    _management_input("Outcome Type", "manage-outcome"),
                    _management_input("Latitude", "manage-lat", placeholder="Optional number"),
                    _management_input("Longitude", "manage-long", placeholder="Optional number"),
                ],
                style={"display": "flex", "gap": "12px", "flexWrap": "wrap"},
            ),
            html.Div(
                [
                    html.Button("Create New Record", id="create-record", n_clicks=0),
                    html.Button("Update Selected Record", id="update-record", n_clicks=0),
                    dcc.ConfirmDialogProvider(
                        id="delete-confirm",
                        message="Delete the currently selected database record? This cannot be undone.",
                        children=html.Button("Delete Selected Record", id="delete-record-button"),
                    ),
                ],
                style={"display": "flex", "gap": "10px", "marginTop": "15px", "flexWrap": "wrap"},
            ),
            html.Div(id="crud-status", role="status", style={"marginTop": "10px", "fontWeight": "bold"}),
            html.Hr(),
            html.Div(id="map-id"),
        ],
        style={"maxWidth": "1400px", "margin": "0 auto", "padding": "20px"},
    )
