CS 499 Milestone Four - Enhancement Three: Databases
Student: Angel Levaomana
Date: October 2, 2026

This technical artifact package contains:

1. Original_Artifact/
   - The original CS 340 Grazioso Salvare dashboard code retained for comparison.

2. Enhanced_Artifact/
   - The modular application improved across CS 499 Milestones Two, Three, and Four.
   - database.py now includes record validation, index management, controlled create/update/delete operations, exact ObjectId targeting, aggregation, and safe database error handling.
   - layout.py and callbacks.py add a database summary plus controlled CRUD actions and delete confirmation in the dashboard.
   - services.py preserves MongoDB _id as record_id so one exact document can be updated or deleted safely.
   - tests/ now contains 30 automated tests across the services/algorithms and database enhancements.
   - README.md documents the complete enhancement and setup.
   - TEST_RESULTS.txt records automated verification.

The local .env file is not included. Use .env.example to configure a local .env file when running the dashboard. The application supports authenticated MongoDB connections and local development MongoDB instances with authentication disabled.
