CS 340 Grazioso Salvare Dashboard - Original Artifact for CS 499

Files:
- ProjectTwoDashboard_REDACTED.ipynb
- CRUD_Python_Module.py

Security note: Database credentials from the original notebook were removed before submission. Environment-variable placeholders are used instead.
